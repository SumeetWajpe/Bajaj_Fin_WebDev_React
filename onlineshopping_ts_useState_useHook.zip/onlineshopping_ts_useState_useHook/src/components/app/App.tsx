import React from "react";
import logo from "./logo.svg";
import "./App.css";

import ListOfProducts from "../listofproducts/listofproducts";
import Counter from "../counter/counter";
import Posts from "../posts/posts";

function App() {
  // return <ListOfProducts />;
  // return <Counter initialValue={100} initialAge={18} />;
  return <Posts />;
}

export default App;
