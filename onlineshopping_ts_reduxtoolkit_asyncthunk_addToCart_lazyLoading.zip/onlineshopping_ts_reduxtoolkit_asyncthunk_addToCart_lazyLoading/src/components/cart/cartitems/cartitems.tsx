import React from "react";
import { useAppSelector } from "../../../redux/store/store";
import { useDispatch } from "react-redux";
import { ProductModel } from "../../../models/product.model";
import {
  addItemToCart,
  removeItemFromCart,
} from "../../../redux/reducers/cartitems.reducer";
import { incrementLikes } from "../../../redux/reducers/products.reducer";
import { AppDispatch } from "../../../redux/store/store";
import { Button } from "../../button/button";
import { Rating } from "../../rating/rating";

export default function CartItems() {
  const cartStoreData = useAppSelector(store => store.cartItems.cartitems);
  const dispatch = useDispatch<AppDispatch>();
  let cartItemsToBeRendered = cartStoreData.map(item => (
    <div className="card mb-3">
      <div className="row g-2 justify-content-between align-items-center">
        <div className="col-md-3">
          <img />
          <img
            src={item.imageUrl}
            alt={item.title}
            className="img-fluid rounded-start"
          />
        </div>
        <div className="col-md-6">
          <div className="card-body p-2">
            <h5 className="card-title">{item.title}</h5>
            <p className="card-text m-0">
              <Rating noofstars={item.rating} color="orange" />
            </p>

            <p className="card-text "> ₹.{item.price}</p>
          </div>
        </div>
        <div className="col-md-3">
          <div>
            <Button
              classes="btn btn-primary rounded-0 text-light"
              ClickHandler={() => {
                dispatch(incrementLikes(item.id));
              }}
            >
              <i className="fa-solid fa-thumbs-up"></i> {item.likes}
            </Button>

            <Button
              classes="btn btn-danger rounded-0 text-light mx-1"
              ClickHandler={() => dispatch(removeItemFromCart(item.id))}
            >
              <i className="fa-solid fa-trash"></i>
            </Button>
          </div>
        </div>
      </div>
    </div>
  ));
  return (
    <>
      {cartStoreData.length ? (
        cartItemsToBeRendered
      ) : (
        <h2 className="text-center">Your cart is Empty !</h2>
      )}
    </>
  );
}
