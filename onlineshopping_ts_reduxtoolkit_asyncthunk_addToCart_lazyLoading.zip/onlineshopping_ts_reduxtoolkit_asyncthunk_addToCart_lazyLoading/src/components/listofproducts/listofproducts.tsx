import React, { useState } from "react";
import { useSelector } from "react-redux";
import { ProductModel } from "../../models/product.model";
import { RootState, useAppSelector } from "../../redux/store/store";
import NewProduct from "../newproduct/newproduct";
import Product from "../product/product";
import ProductsWithLikes from "../productsWithLikes/productswithlikes";
function ListOfProducts() {
  const productsStoreData = useAppSelector(store => store.products);
  let productsToBeCreated = productsStoreData.products.map(p => (
    <Product productdetails={p} key={p.id} />
  ));

  return (
    <div>
      <div className="row g-3">{productsToBeCreated}</div>
    </div>
  );
}

export default ListOfProducts;
