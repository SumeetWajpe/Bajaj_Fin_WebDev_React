import React from "react";
import logo from "./logo.svg";
import "./App.css";

import ListOfProducts from "../listofproducts/listofproducts";

class App extends React.Component {
  render(): React.ReactNode {
    return <ListOfProducts />;
  }
}

export default App;
