import React from "react";
import "./button.css";
type ButtonProps = {
  classes: string;
  children: string | React.ReactNode | React.ReactNode[];
};
export class Button extends React.Component<ButtonProps> {
  render(): React.ReactNode {
    return (
      <button className={this.props.classes}>{this.props.children}</button>
    );
  }
}
