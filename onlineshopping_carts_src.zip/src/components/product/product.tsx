import React from "react";
import { ProductModel } from "../../models/product.model";
import { Button } from "../button/button";
import { Rating } from "../rating/rating";

// interface ProductProps {
//   productdetails: ProductModel;
// }

type ProductProps = {
  productdetails: ProductModel;
};

class Product extends React.Component<ProductProps> {
  render(): React.ReactNode {
    return (
      <div className="col-sm-6 col-md-4 col-lg-3">
        <div
          className="card rounded-0"
          style={{ boxShadow: "3px 3px 5px gray" }}
        >
          <img
            src={this.props.productdetails.imageUrl}
            alt={this.props.productdetails.title}
            className="card-img-top rounded-0"
            height="200px"
          />
          <div className="card-body p-2">
            <div className="d-flex flex-wrap justify-content-between">
              <h5 className="card-title">{this.props.productdetails.title}</h5>
              <p className="card-text m-0">
                <Rating
                  noofstars={this.props.productdetails.rating}
                  color="orange"
                />
              </p>
            </div>

            <p className="card-text "> ₹.{this.props.productdetails.price}</p>

            <div className="d-flex flex-wrap">
              <Button classes="btn btn-primary rounded-0 text-light">
                <i className="fa-solid fa-thumbs-up"></i>{" "}
                {this.props.productdetails.likes}
              </Button>
              <Button classes="btn btn-primary btn-outline rounded-0 mx-1 text-dark">
                <i className="fa-regular fa-heart"></i>
              </Button>
              <Button classes="btn btn-danger rounded-0 text-light">
                <i className="fa-solid fa-trash"></i>
              </Button>
            </div>

            {/* <Button bgColor="white" textColor="black" text="Add to favourite" /> */}
          </div>
          <Button classes="btn btn-primary btn-purple rounded-0 border-0 m-1 font-weight-bold">
            <i className="fa-solid fa-cart-plus"></i> Add to cart
          </Button>
        </div>
      </div>
    );
  }
}

export default Product;
