import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

type PostState = {
  userId: number;
  id: number;
  title: string;
  body: string;
};
export default function Posts() {
  const [posts, setPosts] = useState<PostState[]>([]);

  useEffect(() => {
    // async call
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then(res => res.json())
      .then(posts => {
        console.log(posts);
        setPosts(posts);
      });
  }, []);
  return (
    <div>
      <header>
        <h1>All Posts</h1>
      </header>
      <section>
        <ul className="list-group">
          {posts.map(post => (
            <li className="list-group-item list-group-item-primary m-1">
              <Link to={`/postdetails/${post.id}`}>{post.title}</Link>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
