import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { PostModel } from "../../models/post.model";

export interface PostsState {
  posts: PostModel[];
}

const initialState: PostsState = {
  posts: [{ id: 1, title: "Dummy", body: "Dummy", userId: 1 }],
};

export const postsSlice = createSlice({
  name: "posts",
  initialState,
  reducers: {
    addPost(store, action: PayloadAction<PostModel>) {
      store.posts.push(action.payload);
    },
  },
});

export const { addPost } = postsSlice.actions;

export default postsSlice.reducer;
