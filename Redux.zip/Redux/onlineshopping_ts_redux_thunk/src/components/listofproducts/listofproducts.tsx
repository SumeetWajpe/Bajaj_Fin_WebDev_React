import React, { useState } from "react";
import { useSelector } from "react-redux";
import { ProductModel } from "../../models/product.model";
import NewProduct from "../newproduct/newproduct";
import Product from "../product/product";
function ListOfProducts() {
  let products = useSelector((store: any) => store.products);

  let productsToBeCreated = products.map((p: ProductModel) => (
    <Product productdetails={p} />
  ));

  return (
    <div>
      <div className="row g-3">{productsToBeCreated}</div>
    </div>
  );
}

export default ListOfProducts;

// let [products, setProducts] = useState<ProductModel[]>(productlist);
// let productsToBeCreated = products.map(p => <Product productdetails={p} />);

// function AddNewProduct(newProduct: ProductModel) {
//   // console.log("AddNewProduct Called !");
//   // console.log(newProduct);
//   setProducts([...products, newProduct]);
// }
// return (
//   <div>
//     <div className="row g-3">{productsToBeCreated}</div>
//   </div>
// );
