import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { Link } from "react-router-dom";
import { FetchAllPostsAsync } from "../../redux/actions/actionCreators";
import { StoreType, useTypedDispatch } from "../../redux/store/store";

type PostState = {
  userId: number;
  id: number;
  title: string;
  body: string;
};
export default function Posts() {
  let posts = useSelector((store: StoreType) => store.posts);
  let dispatch = useTypedDispatch();
  useEffect(() => {
    dispatch(FetchAllPostsAsync());
  }, []);
  return (
    <div>
      <header>
        <h1>All Posts</h1>
      </header>
      <section>
        <ul className="list-group">
          {posts.map(post => (
            <li className="list-group-item list-group-item-primary m-1">
              <Link to={`/postdetails/${post.id}`}>{post.title}</Link>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
