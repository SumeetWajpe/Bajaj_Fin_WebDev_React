import { PostModel } from "../../models/post.model";
import { ProductModel } from "../../models/product.model";
import {
  IAddNewProductAction,
  IDeleteProductAction,
  IIncrementLikesAction,
} from "./actiontypes";

const ADD_NEW_PRODUCT = "ADD_NEW_PRODUCT";
export function AddNewProduct(payload: ProductModel): IAddNewProductAction {
  return { type: ADD_NEW_PRODUCT, payload };
}

export function DeleteProduct(payload: number): IDeleteProductAction {
  return { type: "DELETE_PRODUCT", payload };
}

export function IncrementLikes(payload: number): IIncrementLikesAction {
  return { type: "INCREMENT_LIKES_PRODUCT", payload };
}

export function FetchAllPosts(payload: PostModel[]) {
  return { type: "FETCH_POSTS", payload };
}

export function FetchAllPostsAsync() {
  return (dispatch: any) => {
    fetch("https://jsonplaceholder.typicode.com/posts")
      .then(res => res.json())
      .then(posts => dispatch(FetchAllPosts(posts)));
  };
}
