import { PostModel } from "../../models/post.model";

export function posts(store: PostModel[] = [], action: any) {
  switch (action.type) {
    case "FETCH_POSTS":
      return action.payload; // posts 100 records
    case "ADD_POST":
      // biz logic to change the store
      console.log("Inside posts reducer");
      console.log(action);

      return store; // updated store

    default:
      return store; // updated store
  }
}
