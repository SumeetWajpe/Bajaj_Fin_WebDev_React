import { combineReducers } from "redux";
import { posts } from "./posts.reducer";
import { products } from "./products.reducer";

export const rootReducer = combineReducers({ products, posts });
