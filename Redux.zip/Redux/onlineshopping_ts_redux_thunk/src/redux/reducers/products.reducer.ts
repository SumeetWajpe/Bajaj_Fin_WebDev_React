import { ProductModel } from "../../models/product.model";
import {
  IAddNewProductAction,
  IDeleteProductAction,
  IIncrementLikesAction,
} from "../actions/actiontypes";
type ProductActions =
  | IIncrementLikesAction
  | IAddNewProductAction
  | IDeleteProductAction;

export function products(store: ProductModel[] = [], action: ProductActions) {
  let productId: number;
  switch (action.type) {
    case "INCREMENT_LIKES_PRODUCT":
      // biz logic to change the store

      productId = action.payload as number;

      let index = store.findIndex(p => p.id == productId);

      return [
        ...store.slice(0, index),
        { ...store[index], likes: store[index].likes + 1 },
        ...store.slice(index + 1),
      ];

    case "ADD_NEW_PRODUCT":
      // biz logic to change the store

      return [...store, action.payload]; // updated store

    case "DELETE_PRODUCT":
      // biz logic to change the store
      productId = action.payload as number;
      store = store.filter(p => p.id !== productId);

      return store; // updated store

    default:
      return store;
  }
}
