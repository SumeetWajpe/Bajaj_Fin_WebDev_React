export function Add(x, y) {
  return x + y;
}

// export function Product(x, y) {
//   return x * y;
// }

export default function Multiply(x, y) {
  return x * y;
}
