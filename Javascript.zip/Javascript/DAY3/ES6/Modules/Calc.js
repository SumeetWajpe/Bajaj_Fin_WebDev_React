import * as MathModule from "./Math.js";

console.log(`The addition is : ${MathModule.Add(20, 30)}`);
console.log(`The addition is : ${MathModule.default(20, 30)}`);

// OR

// import Multiply, { Add as Addition } from "./Math.js";

// console.log(`The addition is : ${Addition(20, 30)}`);
// // console.log(`The addition is : ${Product(20, 30)}`);
// console.log(`The addition is : ${Multiply(20, 30)}`);
