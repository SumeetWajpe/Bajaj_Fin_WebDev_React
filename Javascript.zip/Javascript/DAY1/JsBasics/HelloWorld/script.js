console.log("Using external JS file !");
