// convert this to use async await
// export all functions - ES6
function FetchProducts() {
  fetch("./data.json")
    .then(function (response) {
      if (response.ok) {
        
        return response.json();
      } else {
        throw new Error("Something went wrong @");
      }
    })
    .then(function (data) {
      HideSpinner();
      DisplayProducts(data);
    });
}

function HideSpinner() {
  document.querySelector(`[role = "status"]`).remove();
}

function DisplayProducts(products) {
  // Use for-of

  for (let index = 0; index < products.length; index++) {
    CreateProductItem(products[index]);
  }
}

function CreateProductItem(theProduct) {
  var divProductItem = document.createElement("div");
  divProductItem.style.border = "2px solid grey";
  divProductItem.style.height = "400px";
  divProductItem.style.width = "300px";
  divProductItem.style.padding = "5px";
  divProductItem.style.margin = "10px";

  var imageProductItem = document.createElement("img");
  imageProductItem.src = theProduct.imageUrl;
  imageProductItem.style.height = "200px";
  imageProductItem.style.width = "280px";

  divProductItem.appendChild(imageProductItem);

  var titleProductItem = document.createElement("h2");
  titleProductItem.innerText = theProduct.title;
  divProductItem.appendChild(titleProductItem);

  var priceProductItem = document.createElement("p");
  priceProductItem.innerText = theProduct.price;
  divProductItem.appendChild(priceProductItem);

  var ratingProductItem = document.createElement("p");
  ratingProductItem.innerText = theProduct.rating;
  divProductItem.appendChild(ratingProductItem);

  var spanRating = document.createElement("span");

  spanRating.style.color = "orange";
  for (let index = 0; index < theProduct.rating; index++) {
    var ratingItem = document.createElement("i");
    ratingItem.className = "fa-star fa-solid";
    spanRating.appendChild(ratingItem);
  }

  divProductItem.appendChild(spanRating);

  var likesProductItem = document.createElement("button");
  likesProductItem.innerText = theProduct.likes;
  likesProductItem.addEventListener("click", function () {
    // theProduct.likes += 1;
    likesProductItem.innerText = ++theProduct.likes;
  });
  divProductItem.appendChild(likesProductItem);

  var divWrapper = document.getElementById("wrapper");
  divWrapper.appendChild(divProductItem);
}

window.addEventListener("DOMContentLoaded", FetchProducts);
