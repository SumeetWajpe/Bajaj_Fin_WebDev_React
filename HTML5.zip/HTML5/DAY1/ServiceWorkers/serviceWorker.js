let cacheAssets = ["Index.html", "About.html"];

self.addEventListener("install", e => {
  console.log("Service Worker : Installed !");
  e.waitUntil(
    caches
      .open("v1")
      .then(cache => {
        cache.addAll(cacheAssets);
      })
      .then(() => self.skipWaiting()),
  );
});

self.addEventListener("activate", () => {
  console.log("Service Worker Activated !");
});

self.addEventListener("fetch", e => {
  e.respondWith(fetch(e.request).catch(() => caches.match(e.request)));
});
