var products = [
  {
    id: 1,
    title: "MacBookPro",
  },
  {
    id: 2,
    title: "MacBookAir",
  },
];


module.exports = products;