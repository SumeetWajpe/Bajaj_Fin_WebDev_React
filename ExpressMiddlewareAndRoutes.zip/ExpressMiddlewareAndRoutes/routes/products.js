const express = require("express");
const router = express.Router();
let products = require("../models/products");
router.get("/", (req, res) => {
  res.json(products);
});

router.post("/newproduct", (req, res) => {
  products.push(req.body);
  console.log(products);
  res.json({ msg: "Product Added Successfully !", title: req.body.title });
});

module.exports = router;
