const express = require("express");
const app = express();
const port = 3000;

const productsRouter = require("./routes/products");

// built-in middleware
app.use(express.static("static"));
app.use(express.json());
app.use("/products", productsRouter);
app.get("/", (req, res) => {
  res.sendFile("Index.html", { root: __dirname });
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});
