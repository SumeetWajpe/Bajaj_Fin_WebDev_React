async function FetchProducts() {
  let response = await fetch("http://localhost:3000/products");
  if (response.ok) {
    let products = await response.json();

    for (const product of products) {
      let newLi = document.createElement("li");
      newLi.innerHTML = product.title;
      document.querySelector(".productList").append(newLi);
    }
  }
}

async function AddNewProduct(e) {
  e.preventDefault(); // does not refresh the page
  let newProduct = {
    id: document.querySelector("#txtProductId").value,
    title: document.querySelector("#txtProductTitle").value,
  };
  // send data to /products/newproduct
  let response = await fetch("http://localhost:3000/products/newproduct", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(newProduct),
  });
  if (response.ok) {
    let message = await response.json();
    console.log(message);
  }
}

window.addEventListener("DOMContentLoaded", FetchProducts);
