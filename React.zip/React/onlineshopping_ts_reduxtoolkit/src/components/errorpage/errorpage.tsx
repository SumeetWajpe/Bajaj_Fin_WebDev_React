import React from "react";

export default function ErrorPage() {
  return (
    <div>
      <h1>Resource not Found</h1>
      <img
        src="https://www.elegantthemes.com/blog/wp-content/uploads/2020/02/000-404.png"
        alt="Resource Not Found"
      />
    </div>
  );
}
