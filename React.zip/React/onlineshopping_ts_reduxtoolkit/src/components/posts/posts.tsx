import React, { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { Link } from "react-router-dom";
import { fetchPostsAsync } from "../../redux/reducers/posts.reducer";
import { AppDispatch, useAppSelector } from "../../redux/store/store";

type PostState = {
  userId: number;
  id: number;
  title: string;
  body: string;
};
export default function Posts() {
  let { posts } = useAppSelector(store => store.posts);
  let dispatch = useDispatch<AppDispatch>();

  useEffect(() => {
    // async call
    dispatch(fetchPostsAsync());
  }, []);

  let contentsToRender;
  let loadingGif = (
    <img
      src="https://miro.medium.com/max/1400/1*Gvgic29bgoiGVLmI6AVbUg.gif"
      alt="Loading.."
    />
  );

  if (posts.length) {
    contentsToRender = (
      <ul className="list-group">
        {posts.map(post => (
          <li
            className="list-group-item list-group-item-primary m-1"
            key={post.id}
          >
            <Link to={`/postdetails/${post.id}`}>{post.title}</Link>
          </li>
        ))}
      </ul>
    );
  } else {
    contentsToRender = loadingGif;
  }
  return (
    <div>
      <header>
        <h1>All Posts</h1>
      </header>
      <section>{contentsToRender}</section>
    </div>
  );
}
