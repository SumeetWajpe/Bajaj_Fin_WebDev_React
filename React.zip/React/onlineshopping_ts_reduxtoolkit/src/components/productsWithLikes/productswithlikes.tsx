import React from "react";
import { useSelector } from "react-redux";
import { RootState } from "../../redux/store/store";

export default function ProductsWithLikes() {
  const productsStoreData = useSelector((store: RootState) => store.products);
  console.log(productsStoreData);
  return (
    <div>
      <ul className="list-group">
        {productsStoreData.products.map(p => (
          <li key={p.id} className="list-group-item">
            {p.title} - {p.likes}
          </li>
        ))}
      </ul>
    </div>
  );
}
