import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { PostModel } from "../../models/post.model";

export interface PostsState {
  posts: PostModel[];
}

const initialState: PostsState = {
  posts: [],
};

export const fetchPostsAsync = createAsyncThunk<PostModel[]>(
  "posts/fetchAllPosts",
  async () => {
    const responseJSON = await fetch(
      "https://jsonplaceholder.typicode.com/posts",
    );

    const response: PostModel[] = await responseJSON.json();
    return response;
  },
);

export const postsSlice = createSlice({
  name: "posts",
  initialState,
  reducers: {},
  extraReducers: builder => {
    builder.addCase(fetchPostsAsync.fulfilled, (store, { payload }) => {
      store.posts.push(...payload);
    });
  },
});

export default postsSlice.reducer;
