import React, { Suspense } from "react";
import logo from "./logo.svg";
import "./App.css";

import ListOfProducts from "../listofproducts/listofproducts";
import Counter from "../counter/counter";
// import Posts from "../posts/posts";
import GetPostById from "../posts/getpostbyId";
import { GrandParent } from "../contextapi/contextapi";
import { BrowserRouter, Route, Routes, Link } from "react-router-dom";
import NewProduct from "../newproduct/newproduct";
import PostDetails from "../postdetails/postdetails";
import ErrorPage from "../errorpage/errorpage";
import Navbar from "../Navbar/navbar";
import CartItems from "../cart/cartitems/cartitems";
import Login from "../login/login";
import Layout from "../layout/layout";
const Posts = React.lazy(() => import("../posts/posts")); // lazy loading

function App() {
  // condtion
  return (
    <>
      <BrowserRouter>
        <Navbar />

        <Routes>
          <Route path="/" element={<ListOfProducts />}></Route>
          <Route path="newproduct" element={<NewProduct />}></Route>
          <Route
            path="posts"
            element={
              <Suspense fallback={<div>Loading...</div>}>
                <Posts />
              </Suspense>
            }
          ></Route>
          <Route path="postdetails/:id" element={<PostDetails />}></Route>
          <Route path="cart" element={<CartItems />}></Route>

          <Route path="*" element={<ErrorPage />}></Route>
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
