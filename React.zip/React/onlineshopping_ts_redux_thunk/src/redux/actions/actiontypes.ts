import { ProductModel } from "../../models/product.model";

export interface IIncrementLikesAction {
  type: string;
  payload: number;
}

export interface IDeleteProductAction extends IIncrementLikesAction {}

export interface IAddNewProductAction {
  type: string;
  payload: ProductModel;
}
