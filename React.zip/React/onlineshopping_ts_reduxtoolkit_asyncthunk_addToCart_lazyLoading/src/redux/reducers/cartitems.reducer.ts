import { createAsyncThunk, createSlice, PayloadAction } from "@reduxjs/toolkit";
import { ProductModel } from "../../models/product.model";
import store from "../store/store";

export interface CartState {
  cartitems: ProductModel[];
}

const initialState: CartState = {
  cartitems: [],
};

export const cartItemsSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    addItemToCart: (store: CartState, action: PayloadAction<ProductModel>) => {
      store.cartitems.push(action.payload);
      return store;
    },
    removeItemFromCart: (store: CartState, action: PayloadAction<number>) => {
      store.cartitems = store.cartitems.filter(p => p.id !== action.payload);
      return store;
    },
  },
});

export const { addItemToCart, removeItemFromCart } = cartItemsSlice.actions;

export default cartItemsSlice.reducer;
