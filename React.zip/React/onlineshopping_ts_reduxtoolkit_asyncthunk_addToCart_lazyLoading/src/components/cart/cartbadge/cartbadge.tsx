import React from "react";
import { Link } from "react-router-dom";
import { useAppSelector } from "../../../redux/store/store";

export default function CartBadge() {
  const cartItemsStore = useAppSelector(store => store.cartItems);
  return (
    <>
      <Link to="/cart" className="d-flex align-items-center">
        <div className="fs-5">
          <i
            className="fa-solid fa-cart-shopping"
            style={{ color: "white" }}
          ></i>
        </div>

        <span className="badge badge-pill bg-primary mx-1">
          {cartItemsStore.cartitems.length}
        </span>
      </Link>
    </>
  );
}
