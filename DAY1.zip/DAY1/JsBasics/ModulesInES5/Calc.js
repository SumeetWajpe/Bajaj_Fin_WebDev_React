console.log("The addition is : " + MathModule.Addition(20, 30));
