var MathModule = (function () {
  function Add(x, y) {
    return x + y;
  }

  function Product(x, y) {
    return x * y;
  }

  function Divide(x, y) {
    return x / y;
  }

  return {
    Addition: Add,
    Product: Product,
  };
})();
