const express = require("express");
const router = express.Router();
let products = require("../models/products");
router.get("/", (req, res) => {
  res.json(products);
});

router.post("/newproduct", (req, res) => {
  products.push(req.body);
  console.log(products);
  res.json({ status: true, msg: "Product Added Successfully !" });
});

module.exports = router;
