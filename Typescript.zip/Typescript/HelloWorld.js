var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var str = "Hello Typescript"; // type inference
//str = 100;
console.log(str);
// Type annotation
var n;
// console.log(n);
var b;
var o;
// let arr = new Array();
var arr = new Array();
arr[0] = 100;
// OR
var array = [100, 200];
var x;
x = 100;
x = "Hello";
function Add(x, y) {
    if (x == 0) {
        return "x should not be zero !";
    }
    return x + y;
}
var result = Add(20, 30);
var Square = function (x) { return x * x; };
// Optional Parameters
// function PrintBook(author: string, title?: string) {
//   console.log(author, title);
// }
// PrintBook("Unknown");
// Default Parameters
function PrintBook(author, title) {
    if (author === void 0) { author = "Unknown"; }
    if (title === void 0) { title = "Unknown"; }
    console.log(author, title);
}
PrintBook();
PrintBook("Usain Bolt", "Faster Than Lightning");
// let person: IPerson = { name: "Vicky", age: 25, xyz: 123 }; // Error
var Car = /** @class */ (function () {
    //   constructor();
    //   constructor(name: string, speed: number);
    //   constructor(name?: any, speed?: any) {
    //     this.name = name;
    //     this.speed = speed;
    //   }
    function Car(name, speed) {
        if (name === void 0) { name = "BMW"; }
        if (speed === void 0) { speed = 100; }
        this.YoM = "1990";
        this.name = name;
        this.speed = speed;
    }
    Car.prototype.accelerate = function () {
        return "The car ".concat(this.name, " is running @ ").concat(this.speed, " kmph !");
    };
    return Car;
}());
// let car = new Car();
// console.log(car.accelerate());
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(name, speed, fly) {
        var _this = _super.call(this, name, speed) || this;
        _this.canFly = fly;
        return _this;
    }
    JamesBondCar.prototype.accelerate = function () {
        return "".concat(_super.prototype.accelerate.call(this), ". The Year of Manufacturing : ").concat(this.YoM);
    };
    JamesBondCar.GetNitroPower = function () {
        console.log(this.name);
        console.log(this.useNitroPower);
    };
    JamesBondCar.useNitroPower = true;
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("AUDI", 300, true);
console.log(jbc.accelerate());
JamesBondCar.GetNitroPower();
