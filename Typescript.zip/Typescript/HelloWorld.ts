let str = "Hello Typescript"; // type inference
//str = 100;
console.log(str);

// Type annotation
let n: number;
// console.log(n);

let b: boolean;
let o: object;
// let arr = new Array();

let arr: Array<number> = new Array<number>();
arr[0] = 100;

// OR

let array: number[] = [100, 200];

let x: number | string;
x = 100;
x = "Hello";

function Add(x: number, y: number): number | string {
  if (x == 0) {
    return "x should not be zero !";
  }
  return x + y;
}

let result: number | string = Add(20, 30);

let Square = (x: number) => x * x;

// Optional Parameters
// function PrintBook(author: string, title?: string) {
//   console.log(author, title);
// }

// PrintBook("Unknown");

// Default Parameters
function PrintBook(
  author: string = "Unknown",
  title: string = "Unknown",
): void {
  console.log(author, title);
}

PrintBook();
PrintBook("Usain Bolt", "Faster Than Lightning");

interface IPerson {
  name: string;
  age: number;
}

// let person: IPerson = { name: "Vicky", age: 25, xyz: 123 }; // Error

class Car {
  // private id:number;
  name: string;
  speed: number;
  protected YoM: string = "1990";

  //   constructor();
  //   constructor(name: string, speed: number);
  //   constructor(name?: any, speed?: any) {
  //     this.name = name;
  //     this.speed = speed;
  //   }
  constructor(name: string = "BMW", speed: number = 100) {
    this.name = name;
    this.speed = speed;
  }

  accelerate(): string {
    return `The car ${this.name} is running @ ${this.speed} kmph !`;
  }
}

// let car = new Car();
// console.log(car.accelerate());

class JamesBondCar extends Car {
  canFly: boolean;
  static useNitroPower: boolean = true;
  constructor(name: string, speed: number, fly: boolean) {
    super(name, speed);
    this.canFly = fly;
  }
  accelerate(): string {
    return `${super.accelerate()}. The Year of Manufacturing : ${this.YoM}`;
  }

  static GetNitroPower() {
    console.log(this.name);
    console.log(this.useNitroPower);
  }
}

let jbc = new JamesBondCar("AUDI", 300, true);
console.log(jbc.accelerate());
JamesBondCar.GetNitroPower();

interface IEmp {
  name: string;
  empId: number;
  salary: number;
  getSalary: () => number;
}
enum Designations {
  Trainer,
  Developer,
  Architech,
}
class Emp implements IEmp {
  name: string;
  empId: number;
  salary: number;
  designation: Designations;
  getSalary(): number {
    return this.salary;
  }
}

var e = new Emp();
e.designation = Designations.Trainer;

// Enhanced Class Syntax

class EnhancedCar {
  constructor(public name: string = "BMW", public speed: number = 200) {}
}

let ec = new EnhancedCar();

// Generics

function Swap<T>(x: T, y: T) {
  // swap logic
}

Swap<number>(20, 30);
Swap<string>("Hello", "Generics");

class Point<T> {
  x: T;
  y: T;
}

let point = new Point<number>();
