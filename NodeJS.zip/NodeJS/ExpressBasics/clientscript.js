console.log("Client script loaded !");
