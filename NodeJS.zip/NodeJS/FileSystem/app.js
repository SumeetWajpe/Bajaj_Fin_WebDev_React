// Async / Non Blocking
// const fs = require("fs");
// fs.readFile("Input.txt", "utf-8", (err, dataFromFile) => {
//   if (err) {
//     console.log(err);
//   } else {
//     console.log(dataFromFile);
//   }
// });
// console.log("Program Ended ");

// Sync
// const fs = require("fs");
// let dataFromFile = fs.readFileSync("Input.txt", { encoding: "utf-8" });
// console.log(dataFromFile);
// console.log("Program Ended !");

// FS using Event Emitter/Streams
const fs = require("fs");
let dataFromFile = "";
const readableStream = fs.createReadStream("Input.txt");
const writableStream = fs.createWriteStream("Output.txt");

// readableStream.on("data", chunk => {
//   dataFromFile += chunk;
//   //   console.log(dataFromFile)
//   console.log(">>>>>>>>>>>>>>> CHUNK >>>>>>>>>>>>>>>>>>>>>");
// });

// readableStream.on("end", () => {
//   writableStream.write(dataFromFile);
//   writableStream.end();
// });

readableStream.pipe(writableStream);

console.log("Program Ended");
