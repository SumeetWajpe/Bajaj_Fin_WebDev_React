const express = require("express");
const fs = require("fs");
const path = require("path");
const app = express();
const port = 3000;

const productsRouter = require("./routes/products");

// built-in middleware
app.use(express.static("static"));
app.use(express.json());
app.use("/products", productsRouter);
app.get("/", (req, res) => {
  res.sendFile("Index.html", { root: __dirname });
});

app.get("/video", (req, res) => {
  const range = req.headers.range;
  console.log(range);
  const videoPath = path.join(__dirname, "videos/React.mp4");

  const videoSize = fs.statSync(videoPath).size;
  // range
  const CHUNK_SIZE = 10 ** 6; // 1 MB
  const start = Number(range.replace(/\D/g, ""));
  const end = Math.min(start + CHUNK_SIZE, videoSize - 1);


  // headers
  const headers = {
    "Content-Range": `bytes ${start}-${end}/${videoSize}`,
    "Accept-Ranges": "bytes",
    "Content-Length": end - start + 1,
    "Content-Type": "video/mp4",
  };
  res.writeHead(206, headers);
  // read the file and send the content
  const videoStream = fs.createReadStream(videoPath, { start, end });
  videoStream.pipe(res);
});

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`);
});


// MongoDB (On Premise)
// - > Mongod (Mongo Daemon)
// -> Shell (mongosh)  - Client for MongoD (CUI)
// Compass - (Client for MongoD) - GUI

// Windows
// 1. C:/data/db
//2. terminal ->  mongod

// MongoDB commands - to be run on mongoshell
// 1. show dbs

// 2. use productsdb

//2. db.createCollection("products")

// 3. To insert a document (record) 
//db.testcollection.insertOne({"id":1,"title":"Test Title"})

// 4. to Insert many recods
// db.testcollection.insertMany([{"id":3,"title":"Test Title 3"},{"id":4,"title":"Test Title 4"}])

// 5. Find all records
// db.testcollection.find({})