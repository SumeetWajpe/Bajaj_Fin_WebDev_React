let os = require("os");
let fs = require("fs");
console.log(os.cpus());
