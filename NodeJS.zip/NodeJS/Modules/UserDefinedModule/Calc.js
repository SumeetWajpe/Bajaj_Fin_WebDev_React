let MathModule = require("./Math");
console.log(`The addition is : ${MathModule.Add(20, 30)}`);
