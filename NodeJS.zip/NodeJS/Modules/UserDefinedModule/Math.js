function Add(x, y) {
  return x + y;
}

function Multiply(x, y) {
  return x * y;
}

// module.exports.Addition = Add;
// module.exports.Product = Multiply;

module.exports = { Add, Multiply };
